
import React, { useState } from 'react';
import { ArrowLeft, Play, Gift, Trophy, Star, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import BottomNavigation from '@/components/BottomNavigation';
import VoiceButton from '@/components/VoiceButton';
import { useNavigate } from 'react-router-dom';

const LiteracyPage = () => {
  const [currentQuiz, setCurrentQuiz] = useState(0);
  const [showQuiz, setShowQuiz] = useState(false);
  const [tokens, setTokens] = useState(250);
  const [level, setLevel] = useState(3);
  const [completedModules, setCompletedModules] = useState([0, 1]);
  const navigate = useNavigate();

  const modules = [
    {
      id: 0,
      title: 'बैंकिंग की मूल बातें',
      description: 'खाता खोलना, ATM का उपयोग',
      duration: '5 मिनट',
      tokens: 50,
      completed: true
    },
    {
      id: 1,
      title: 'लोन की समझ',
      description: 'ब्याज दर, EMI कैलकुलेशन',
      duration: '7 मिनट',
      tokens: 75,
      completed: true
    },
    {
      id: 2,
      title: 'बचत और निवेश',
      description: 'पैसे कैसे बचाएं और बढ़ाएं',
      duration: '6 मिनट',
      tokens: 60,
      completed: false
    },
    {
      id: 3,
      title: 'बीमा की जानकारी',
      description: 'बीमा क्यों जरूरी है',
      duration: '5 मिनट',
      tokens: 55,
      completed: false
    }
  ];

  const quizQuestions = [
    {
      question: 'EMI का मतलब क्या है?',
      options: [
        'Easy Money Income',
        'Equated Monthly Installment',
        'Emergency Money Insurance',
        'Extra Monthly Interest'
      ],
      correct: 1
    },
    {
      question: 'अच्छा Credit Score कितना होता है?',
      options: ['300-500', '500-650', '650-750', '750-900'],
      correct: 3
    }
  ];

  const handleModuleComplete = (moduleId: number) => {
    if (!completedModules.includes(moduleId)) {
      setCompletedModules([...completedModules, moduleId]);
      setTokens(tokens + modules[moduleId].tokens);
      alert(`बधाई हो! आपने ${modules[moduleId].tokens} टोकन जीते हैं!`);
    }
  };

  const startQuiz = () => {
    setShowQuiz(true);
    setCurrentQuiz(0);
  };

  const handleQuizAnswer = (answerIndex: number) => {
    if (answerIndex === quizQuestions[currentQuiz].correct) {
      setTokens(tokens + 25);
      alert('सही जवाब! आपको 25 टोकन मिले।');
    }
    
    if (currentQuiz < quizQuestions.length - 1) {
      setCurrentQuiz(currentQuiz + 1);
    } else {
      setShowQuiz(false);
      alert('क्विज़ पूरी हो गई! कुल मिलाकर आपको 50 टोकन मिले।');
    }
  };

  if (showQuiz) {
    const question = quizQuestions[currentQuiz];
    return (
      <div className="min-h-screen bg-gray-50 pb-20">
        <div className="bg-white shadow-sm p-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowQuiz(false)}
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-lg font-semibold">वित्तीय क्विज़</h1>
          </div>
          <VoiceButton />
        </div>

        <div className="p-4">
          <div className="max-w-md mx-auto">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-8 h-8 text-purple-600" />
              </div>
              <h2 className="text-xl font-bold mb-2">प्रश्न {currentQuiz + 1}</h2>
              <p className="text-gray-600">{question.question}</p>
            </div>

            <div className="space-y-3">
              {question.options.map((option, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="w-full h-14 text-left justify-start text-wrap"
                  onClick={() => handleQuizAnswer(index)}
                >
                  <span className="mr-3 font-bold">{String.fromCharCode(65 + index)}.</span>
                  {option}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <div className="bg-white shadow-sm p-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('/dashboard')}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-semibold">वित्तीय शिक्षा</h1>
        </div>
        <VoiceButton />
      </div>

      <div className="p-4 space-y-6">
        <Card className="bg-gradient-to-r from-purple-100 to-pink-100 border-purple-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center">
                  <Trophy className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="font-semibold text-purple-800">लेवल {level}</p>
                  <p className="text-sm text-purple-600">{tokens} टोकन</p>
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center space-x-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < level ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
                <p className="text-xs text-purple-600 mt-1">प्रगति</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div>
          <h2 className="text-xl font-bold mb-4">सीखने के मॉड्यूल</h2>
          <div className="space-y-3">
            {modules.map((module) => (
              <Card key={module.id} className="card-hover">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                        module.completed ? 'bg-green-100' : 'bg-blue-100'
                      }`}>
                        {module.completed ? (
                          <CheckCircle className="w-6 h-6 text-green-600" />
                        ) : (
                          <Play className="w-6 h-6 text-blue-600" />
                        )}
                      </div>
                      <div>
                        <h3 className="font-semibold">{module.title}</h3>
                        <p className="text-sm text-gray-600">{module.description}</p>
                        <p className="text-xs text-gray-500">{module.duration}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center space-x-1 mb-1">
                        <Gift className="w-4 h-4 text-green-500" />
                        <span className="text-sm font-medium text-green-600">
                          +{module.tokens}
                        </span>
                      </div>
                      <Button
                        size="sm"
                        variant={module.completed ? "secondary" : "default"}
                        onClick={() => handleModuleComplete(module.id)}
                        disabled={module.completed}
                      >
                        {module.completed ? 'पूरा' : 'शुरू करें'}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <Card className="bg-gradient-to-r from-orange-100 to-yellow-100 border-orange-200">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Star className="w-5 h-5 text-orange-500" />
              <span>दैनिक क्विज़</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700 mb-4">
              अपने ज्ञान को परखें और रोज़ाना टोकन जीतें!
            </p>
            <Button
              className="w-full bg-orange-500 hover:bg-orange-600"
              onClick={startQuiz}
            >
              <Star className="w-4 h-4 mr-2" />
              क्विज़ शुरू करें (+50 टोकन)
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>आपकी उपलब्धियां</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 bg-blue-50 rounded-lg">
                <p className="text-2xl font-bold text-blue-600">{completedModules.length}</p>
                <p className="text-sm text-gray-600">मॉड्यूल पूरे</p>
              </div>
              <div className="text-center p-3 bg-green-50 rounded-lg">
                <p className="text-2xl font-bold text-green-600">{tokens}</p>
                <p className="text-sm text-gray-600">कुल टोकन</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <BottomNavigation />
    </div>
  );
};

export default LiteracyPage;
