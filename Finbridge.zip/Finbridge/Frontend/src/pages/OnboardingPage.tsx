
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Camera, Phone, CreditCard, Globe } from 'lucide-react';
import VoiceButton from '@/components/VoiceButton';

const OnboardingPage = () => {
  const [language, setLanguage] = useState('hi');
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    aadhaar: '',
    phone: '',
    selfie: null as File | null
  });
  const navigate = useNavigate();

  const content = {
    hi: {
      welcome: 'FinBridge में आपका स्वागत है',
      subtitle: 'आसान लोन और वित्तीय सेवाएं',
      aadhaarLabel: 'आधार नंबर दर्ज करें',
      phoneLabel: 'मोबाइल नंबर दर्ज करें',
      selfieLabel: 'सेल्फी अपलोड करें',
      continue: 'आगे बढ़ें',
      finish: 'शुरू करें'
    },
    en: {
      welcome: 'Welcome to FinBridge',
      subtitle: 'Easy loans and financial services',
      aadhaarLabel: 'Enter Aadhaar Number',
      phoneLabel: 'Enter Mobile Number',
      selfieLabel: 'Upload Selfie',
      continue: 'Continue',
      finish: 'Get Started'
    }
  };

  const text = content[language as keyof typeof content];

  const handleNext = () => {
    if (step < 3) {
      setStep(step + 1);
    } else {
      navigate('/dashboard');
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFormData({ ...formData, selfie: file });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white flex flex-col">
      <div className="flex justify-between items-center p-4">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-green-500 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold">F</span>
          </div>
          <h1 className="text-lg font-bold text-gray-900">FinBridge</h1>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLanguage(language === 'en' ? 'hi' : 'en')}
            className="flex items-center space-x-1"
          >
            <Globe className="w-4 h-4" />
            <span>{language === 'en' ? 'हिंदी' : 'English'}</span>
          </Button>
          <VoiceButton />
        </div>
      </div>

      <div className="flex-1 px-6 py-8">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">{text.welcome}</h2>
          <p className="text-gray-600">{text.subtitle}</p>
        </div>

        <div className="max-w-md mx-auto">
          <div className="flex justify-center mb-6">
            <div className="flex space-x-2">
              {[1, 2, 3].map((i) => (
                <div
                  key={i}
                  className={`w-3 h-3 rounded-full ${
                    i <= step ? 'bg-blue-500' : 'bg-gray-300'
                  }`}
                />
              ))}
            </div>
          </div>

          {step === 1 && (
            <div className="space-y-4 animate-fade-in">
              <div className="text-center mb-6">
                <CreditCard className="w-16 h-16 mx-auto text-blue-500 mb-4" />
              </div>
              <div>
                <Label htmlFor="aadhaar" className="text-base font-medium">
                  {text.aadhaarLabel}
                </Label>
                <Input
                  id="aadhaar"
                  type="text"
                  placeholder="XXXX XXXX XXXX"
                  value={formData.aadhaar}
                  onChange={(e) => setFormData({ ...formData, aadhaar: e.target.value })}
                  className="mt-2 h-12 text-lg"
                  maxLength={12}
                />
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4 animate-fade-in">
              <div className="text-center mb-6">
                <Phone className="w-16 h-16 mx-auto text-green-500 mb-4" />
              </div>
              <div>
                <Label htmlFor="phone" className="text-base font-medium">
                  {text.phoneLabel}
                </Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="+91 XXXXX XXXXX"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="mt-2 h-12 text-lg"
                />
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4 animate-fade-in">
              <div className="text-center mb-6">
                <Camera className="w-16 h-16 mx-auto text-purple-500 mb-4" />
              </div>
              <div>
                <Label htmlFor="selfie" className="text-base font-medium">
                  {text.selfieLabel}
                </Label>
                <div className="mt-2 border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                  <input
                    id="selfie"
                    type="file"
                    accept="image/*"
                    capture="user"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <label htmlFor="selfie" className="cursor-pointer">
                    <Camera className="w-12 h-12 mx-auto text-gray-400 mb-2" />
                    <p className="text-gray-600">टैप करें फोटो लेने के लिए</p>
                  </label>
                </div>
              </div>
            </div>
          )}

          <Button
            onClick={handleNext}
            className="w-full h-12 text-lg font-medium mt-8 bg-gradient-to-r from-blue-500 to-green-500 hover:from-blue-600 hover:to-green-600"
          >
            {step === 3 ? text.finish : text.continue}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default OnboardingPage;
