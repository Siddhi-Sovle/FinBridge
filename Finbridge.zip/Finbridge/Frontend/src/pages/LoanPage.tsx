
import React, { useState } from 'react';
import { ArrowLeft, Upload, Calculator, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import BottomNavigation from '@/components/BottomNavigation';
import VoiceButton from '@/components/VoiceButton';
import { useNavigate } from 'react-router-dom';

const LoanPage = () => {
  const [loanAmount, setLoanAmount] = useState([2500]);
  const [tenure, setTenure] = useState([3]);
  const [monthlyIncome, setMonthlyIncome] = useState('');
  const [documents, setDocuments] = useState<File[]>([]);
  const navigate = useNavigate();

  const interestRate = 2.5; // Monthly interest rate
  const emi = (loanAmount[0] * (1 + (interestRate / 100))) / tenure[0];

  const handleDocumentUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setDocuments([...documents, ...files]);
  };

  const handleSubmitApplication = () => {
    // Simulate loan application submission
    alert('लोन आवेदन सफलतापूर्वक जमा किया गया! आपको 24 घंटे में जवाब मिलेगा।');
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <div className="bg-white shadow-sm p-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('/dashboard')}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-semibold">माइक्रो लोन आवेदन</h1>
        </div>
        <VoiceButton />
      </div>

      <div className="p-4 space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Calculator className="w-5 h-5 text-blue-500" />
              <span>लोन राशि चुनें</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label className="text-base font-medium">
                  राशि: ₹{loanAmount[0].toLocaleString()}
                </Label>
                <Slider
                  value={loanAmount}
                  onValueChange={setLoanAmount}
                  max={5000}
                  min={500}
                  step={100}
                  className="mt-3"
                />
                <div className="flex justify-between text-sm text-gray-500 mt-2">
                  <span>₹500</span>
                  <span>₹5,000</span>
                </div>
              </div>

              <div>
                <Label className="text-base font-medium">
                  अवधि: {tenure[0]} महीने
                </Label>
                <Slider
                  value={tenure}
                  onValueChange={setTenure}
                  max={6}
                  min={1}
                  step={1}
                  className="mt-3"
                />
                <div className="flex justify-between text-sm text-gray-500 mt-2">
                  <span>1 महीना</span>
                  <span>6 महीने</span>
                </div>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="flex items-center justify-between">
                  <span className="font-medium">मासिक EMI:</span>
                  <span className="text-xl font-bold text-blue-600">
                    ₹{Math.round(emi).toLocaleString()}
                  </span>
                </div>
                <p className="text-sm text-gray-600 mt-1">
                  ब्याज दर: {interestRate}% प्रति महीना
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>आय की जानकारी</CardTitle>
          </CardHeader>
          <CardContent>
            <div>
              <Label htmlFor="income" className="text-base font-medium">
                मासिक आय (₹)
              </Label>
              <Input
                id="income"
                type="number"
                placeholder="₹8,000"
                value={monthlyIncome}
                onChange={(e) => setMonthlyIncome(e.target.value)}
                className="mt-2 h-12 text-lg"
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Upload className="w-5 h-5 text-green-500" />
              <span>दस्तावेज़ अपलोड करें</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6">
                <input
                  type="file"
                  multiple
                  accept="image/*,.pdf"
                  onChange={handleDocumentUpload}
                  className="hidden"
                  id="document-upload"
                />
                <label
                  htmlFor="document-upload"
                  className="cursor-pointer text-center block"
                >
                  <Upload className="w-12 h-12 mx-auto text-gray-400 mb-2" />
                  <p className="text-gray-600">
                    बिजली का बिल / किराया रसीद अपलोड करें
                  </p>
                  <p className="text-sm text-gray-500 mt-1">
                    JPG, PNG या PDF (अधिकतम 5MB)
                  </p>
                </label>
              </div>

              {documents.length > 0 && (
                <div className="space-y-2">
                  <p className="font-medium">अपलोड किए गए दस्तावेज़:</p>
                  {documents.map((doc, index) => (
                    <div key={index} className="flex items-center space-x-2 text-sm">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span>{doc.name}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-yellow-50 border-yellow-200">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <Clock className="w-5 h-5 text-yellow-600 mt-0.5" />
              <div>
                <h3 className="font-medium text-yellow-800">प्रोसेसिंग टाइम</h3>
                <p className="text-sm text-yellow-700">
                  आपका आवेदन 24 घंटे में प्रोसेस हो जाएगा। अप्रूवल के बाद पैसा 
                  सीधे आपके खाते में भेज दिया जाएगा।
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Button
          onClick={handleSubmitApplication}
          className="w-full h-12 text-lg font-medium bg-gradient-to-r from-blue-500 to-green-500 hover:from-blue-600 hover:to-green-600"
          disabled={!monthlyIncome || documents.length === 0}
        >
          लोन के लिए आवेदन करें
        </Button>
      </div>

      <BottomNavigation />
    </div>
  );
};

export default LoanPage;
