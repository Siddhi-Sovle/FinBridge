
import React, { useState } from 'react';
import Header from '../components/Header';
import Hero from '../components/Hero';
import Features from '../components/Features';
import HowItWorks from '../components/HowItWorks';
import Testimonials from '../components/Testimonials';
import Security from '../components/Security';
import Contact from '../components/Contact';
import Footer from '../components/Footer';

const Index = () => {
  const [language, setLanguage] = useState('en');

  return (
    <div className="min-h-screen bg-white">
      <Header language={language} setLanguage={setLanguage} />
      <Hero language={language} />
      <Features language={language} />
      <HowItWorks language={language} />
      <Testimonials language={language} />
      <Security language={language} />
      <Contact language={language} />
      <Footer language={language} />
    </div>
  );
};

export default Index;
