
import React, { useState } from 'react';
import { ArrowLeft, Shield, Lock, Eye, Brain, Smartphone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import BottomNavigation from '@/components/BottomNavigation';
import VoiceButton from '@/components/VoiceButton';
import { useNavigate } from 'react-router-dom';

const SecurityPage = () => {
  const navigate = useNavigate();
  const [showExplainableAI, setShowExplainableAI] = useState(false);

  const securityFeatures = [
    {
      icon: Lock,
      title: '256-bit एन्क्रिप्शन',
      description: 'आपका डेटा बैंक-लेवल सिक्योरिटी से सुरक्षित है',
      status: 'active'
    },
    {
      icon: Eye,
      title: 'बायोमेट्रिक लॉगिन',
      description: 'फिंगरप्रिंट और फेस ID से सुरक्षित एक्सेस',
      status: 'active'
    },
    {
      icon: Smartphone,
      title: 'SMS OTP वेरिफिकेशन',
      description: 'हर ट्रांजेक्शन पर डबल चेक',
      status: 'active'
    }
  ];

  const aiFactors = [
    {
      factor: 'फोन उपयोग पैटर्न',
      weight: 25,
      description: 'नियमित फोन उपयोग आपकी स्थिरता दिखाता है',
      color: 'bg-blue-500'
    },
    {
      factor: 'किराया भुगतान',
      weight: 30,
      description: 'समय पर किराया भुगतान अच्छी वित्तीय आदत है',
      color: 'bg-green-500'
    },
    {
      factor: 'GPS स्थिरता',
      weight: 20,
      description: 'एक ही जगह रहना स्थिरता का संकेत है',
      color: 'bg-purple-500'
    },
    {
      factor: 'ऑनलाइन गतिविधि',
      weight: 15,
      description: 'डिजिटल फुटप्रिंट आपकी सक्रियता दिखाता है',
      color: 'bg-orange-500'
    },
    {
      factor: 'सामाजिक नेटवर्क',
      weight: 10,
      description: 'स्थिर रिश्ते बेहतर रीपेमेंट क्षमता दिखाते हैं',
      color: 'bg-pink-500'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <div className="bg-white shadow-sm p-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('/dashboard')}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-semibold">सुरक्षा और गोपनीयता</h1>
        </div>
        <VoiceButton />
      </div>

      <div className="p-4 space-y-6">
        <Card className="bg-gradient-to-r from-green-100 to-blue-100 border-green-200">
          <CardContent className="p-6 text-center">
            <Shield className="w-16 h-16 mx-auto text-green-600 mb-4" />
            <h2 className="text-xl font-bold text-green-800 mb-2">
              आपका डेटा 100% सुरक्षित है
            </h2>
            <p className="text-green-700">
              हम बैंक-ग्रेड सिक्योरिटी का उपयोग करते हैं और आपकी जानकारी को 
              एन्क्रिप्ट करके रखते हैं।
            </p>
          </CardContent>
        </Card>

        <div>
          <h3 className="text-lg font-semibold mb-4">सुरक्षा फीचर्स</h3>
          <div className="space-y-3">
            {securityFeatures.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index}>
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                        <Icon className="w-6 h-6 text-green-600" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">{feature.title}</h4>
                        <p className="text-sm text-gray-600">{feature.description}</p>
                      </div>
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Brain className="w-5 h-5 text-blue-500" />
              <span>AI स्कोरिंग की पारदर्शिता</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">
              हमारा AI आपका Credit Score कैसे निकालता है, यह जानें:
            </p>
            
            <Dialog>
              <DialogTrigger asChild>
                <Button className="w-full bg-blue-500 hover:bg-blue-600">
                  AI स्कोरिंग देखें
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>आपका Credit Score कैसे बना</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  {aiFactors.map((factor, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">{factor.factor}</span>
                        <span className="text-sm text-gray-600">{factor.weight}%</span>
                      </div>
                      <Progress value={factor.weight} className="h-2" />
                      <p className="text-xs text-gray-600">{factor.description}</p>
                    </div>
                  ))}
                  
                  <div className="mt-6 p-3 bg-blue-50 rounded-lg">
                    <p className="text-sm text-blue-800">
                      यह सब मिलकर आपका Alt-Credit Score 720 बनता है, जो "अच्छा" कैटेगरी में है।
                    </p>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>डेटा उपयोग नीति</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm">
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                <p>हम आपका डेटा सिर्फ Credit Score बनाने के लिए उपयोग करते हैं</p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                <p>आपकी व्यक्तिगत जानकारी कभी किसी तीसरे पक्ष के साथ साझा नहीं की जाती</p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                <p>आप कभी भी अपना डेटा डिलीट करवा सकते हैं</p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                <p>सभी डेटा भारत में स्टोर किया जाता है</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-yellow-50 border-yellow-200">
          <CardContent className="p-4">
            <h4 className="font-semibold text-yellow-800 mb-2">
              क्या आपको कोई सुरक्षा चिंता है?
            </h4>
            <p className="text-sm text-yellow-700 mb-3">
              हमारी सुरक्षा टीम से 24/7 संपर्क करें
            </p>
            <Button variant="outline" className="border-yellow-300 text-yellow-800">
              सुरक्षा टीम से बात करें
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-red-600">खाता सेटिंग्स</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <Button variant="outline" className="w-full justify-start">
                डेटा डाउनलोड करें
              </Button>
              <Button variant="outline" className="w-full justify-start">
                डेटा डिलीट करें
              </Button>
              <Button variant="outline" className="w-full justify-start text-red-600 border-red-200 hover:bg-red-50">
                खाता बंद करें
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <BottomNavigation />
    </div>
  );
};

export default SecurityPage;
