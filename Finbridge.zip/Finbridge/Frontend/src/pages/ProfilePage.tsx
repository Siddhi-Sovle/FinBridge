
import React, { useState } from 'react';
import { ArrowLeft, User, CreditCard, History, TrendingUp, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import BottomNavigation from '@/components/BottomNavigation';
import VoiceButton from '@/components/VoiceButton';
import { useNavigate } from 'react-router-dom';

const ProfilePage = () => {
  const navigate = useNavigate();
  const [kycStatus] = useState('verified');
  const creditScore = 720;
  const trustMeter = 85;

  const loanHistory = [
    {
      id: 1,
      amount: 3000,
      status: 'repaid',
      date: '15 नव 2024',
      type: 'माइक्रो लोन'
    },
    {
      id: 2,
      amount: 1500,
      status: 'active',
      date: '01 दिस 2024',
      type: 'इमरजेंसी लोन'
    }
  ];

  const kycDocuments = [
    { name: 'आधार कार्ड', status: 'verified' },
    { name: 'पैन कार्ड', status: 'verified' },
    { name: 'बैंक स्टेटमेंट', status: 'pending' },
    { name: 'सेल्फी', status: 'verified' }
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <div className="bg-white shadow-sm p-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('/dashboard')}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-semibold">मेरी प्रोफाइल</h1>
        </div>
        <VoiceButton />
      </div>

      <div className="p-4 space-y-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center">
                <User className="w-8 h-8 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold">राहुल कुमार</h2>
                <p className="text-gray-600">+91 98765 43210</p>
                <div className="flex items-center space-x-2 mt-1">
                  <div className={`w-2 h-2 rounded-full ${
                    kycStatus === 'verified' ? 'bg-green-500' : 'bg-yellow-500'
                  }`}></div>
                  <span className="text-sm text-gray-600">
                    KYC {kycStatus === 'verified' ? 'सत्यापित' : 'पेंडिंग'}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-2 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-2">
                <TrendingUp className="w-6 h-6 text-blue-600" />
              </div>
              <p className="text-2xl font-bold text-blue-600">{creditScore}</p>
              <p className="text-sm text-gray-600">Credit Score</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4 text-center">
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-2">
                <Shield className="w-6 h-6 text-green-600" />
              </div>
              <p className="text-2xl font-bold text-green-600">{trustMeter}%</p>
              <p className="text-sm text-gray-600">Trust Meter</p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Shield className="w-5 h-5 text-green-500" />
              <span>Trust Meter</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm">रीपेमेंट हिस्ट्री</span>
                <span className="text-sm font-medium">95%</span>
              </div>
              <Progress value={95} className="h-2" />
              
              <div className="flex justify-between items-center">
                <span className="text-sm">फोन स्टेबिलिटी</span>
                <span className="text-sm font-medium">80%</span>
              </div>
              <Progress value={80} className="h-2" />
              
              <div className="flex justify-between items-center">
                <span className="text-sm">लोकेशन स्टेबिलिटी</span>
                <span className="text-sm font-medium">75%</span>
              </div>
              <Progress value={75} className="h-2" />
            </div>
            
            <div className="mt-4 p-3 bg-green-50 rounded-lg">
              <p className="text-sm text-green-800">
                आपका Trust Score बहुत अच्छा है! इससे आपको बेहतर लोन ऑफर मिल सकते हैं।
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <CreditCard className="w-5 h-5 text-blue-500" />
              <span>KYC दस्तावेज़</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {kycDocuments.map((doc, index) => (
                <div key={index} className="flex items-center justify-between">
                  <span className="text-sm">{doc.name}</span>
                  <div className="flex items-center space-x-2">
                    <div className={`w-2 h-2 rounded-full ${
                      doc.status === 'verified' ? 'bg-green-500' : 'bg-yellow-500'
                    }`}></div>
                    <span className={`text-xs ${
                      doc.status === 'verified' ? 'text-green-600' : 'text-yellow-600'
                    }`}>
                      {doc.status === 'verified' ? 'सत्यापित' : 'पेंडिंग'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <History className="w-5 h-5 text-purple-500" />
              <span>लोन हिस्ट्री</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {loanHistory.map((loan) => (
                <div key={loan.id} className="border rounded-lg p-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-medium">₹{loan.amount.toLocaleString()}</p>
                      <p className="text-sm text-gray-600">{loan.type}</p>
                      <p className="text-xs text-gray-500">{loan.date}</p>
                    </div>
                    <div className={`px-2 py-1 rounded-full text-xs ${
                      loan.status === 'repaid' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-blue-100 text-blue-800'
                    }`}>
                      {loan.status === 'repaid' ? 'चुकता' : 'चालू'}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Button
          variant="outline"
          className="w-full h-12 text-red-600 border-red-200 hover:bg-red-50"
        >
          खाता बंद करें
        </Button>
      </div>

      <BottomNavigation />
    </div>
  );
};

export default ProfilePage;
