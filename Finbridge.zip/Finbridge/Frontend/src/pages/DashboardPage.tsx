
import React, { useState } from 'react';
import { CreditCard, Shield, BookOpen, TrendingUp, Gift } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import BottomNavigation from '@/components/BottomNavigation';
import VoiceButton from '@/components/VoiceButton';
import { useNavigate } from 'react-router-dom';

const DashboardPage = () => {
  const [language] = useState('hi');
  const navigate = useNavigate();
  
  const creditScore = 720;
  const loanEligibility = 15000;
  const literacyProgress = 65;
  const tokens = 250;

  const content = {
    hi: {
      welcome: 'नमस्ते',
      userName: 'राहुल जी',
      creditScore: 'Alt-Credit स्कोर',
      loanEligible: 'लोन योग्यता',
      applyLoan: 'माइक्रो लोन',
      insurance: 'बीमा',
      literacy: 'वित्तीय शिक्षा',
      viewOffers: 'ऑफर देखें',
      tokens: 'टोकन'
    }
  };

  const text = content[language as keyof typeof content];

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <div className="bg-gradient-to-r from-blue-500 to-green-500 text-white p-6 rounded-b-3xl">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h1 className="text-xl font-bold">{text.welcome}</h1>
            <p className="text-blue-100">{text.userName}</p>
          </div>
          <VoiceButton className="bg-white/20 border-white/30 text-white" />
        </div>

        <div className="grid grid-cols-2 gap-4 mt-6">
          <div className="bg-white/20 rounded-xl p-4">
            <p className="text-blue-100 text-sm">{text.creditScore}</p>
            <p className="text-2xl font-bold">{creditScore}</p>
            <div className="flex items-center mt-2">
              <TrendingUp className="w-4 h-4 mr-1" />
              <span className="text-sm">अच्छा</span>
            </div>
          </div>
          
          <div className="bg-white/20 rounded-xl p-4">
            <p className="text-blue-100 text-sm">{text.loanEligible}</p>
            <p className="text-2xl font-bold">₹{loanEligibility.toLocaleString()}</p>
            <div className="flex items-center mt-2">
              <Gift className="w-4 h-4 mr-1" />
              <span className="text-sm">{tokens} {text.tokens}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-4">
        <Card className="card-hover" onClick={() => navigate('/loan')}>
          <CardHeader className="pb-3">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                <CreditCard className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <CardTitle className="text-lg">{text.applyLoan}</CardTitle>
                <p className="text-sm text-gray-600">₹500 - ₹5000</p>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Button variant="outline" className="w-full">
              अभी अप्लाई करें
            </Button>
          </CardContent>
        </Card>

        <Card className="card-hover">
          <CardHeader className="pb-3">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                <Shield className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <CardTitle className="text-lg">{text.insurance}</CardTitle>
                <p className="text-sm text-gray-600">Pay-as-you-go</p>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Button variant="outline" className="w-full">
              बीमा देखें
            </Button>
          </CardContent>
        </Card>

        <Card className="card-hover" onClick={() => navigate('/literacy')}>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                  <BookOpen className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <CardTitle className="text-lg">{text.literacy}</CardTitle>
                  <p className="text-sm text-gray-600">{literacyProgress}% पूरा</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium text-green-600">+{tokens}</p>
                <p className="text-xs text-gray-500">टोकन</p>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Progress value={literacyProgress} className="mb-3" />
            <Button variant="outline" className="w-full">
              सीखना जारी रखें
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-orange-100 to-pink-100 border-orange-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-orange-800">पेंडिंग ऑफर</h3>
                <p className="text-sm text-orange-600">2 नए ऑफर उपलब्ध हैं</p>
              </div>
              <Button 
                size="sm" 
                className="bg-orange-500 hover:bg-orange-600"
                onClick={() => navigate('/offers')}
              >
                {text.viewOffers}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <BottomNavigation />
    </div>
  );
};

export default DashboardPage;
