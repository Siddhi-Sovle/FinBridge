
import React from 'react';
import { Phone, Mail, MapPin, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';

interface FooterProps {
  language: string;
}

const Footer = ({ language }: FooterProps) => {
  const content = {
    en: {
      tagline: 'Empowering financial inclusion through AI',
      links: {
        product: 'Product',
        features: 'Features',
        howItWorks: 'How It Works',
        security: 'Security',
        support: 'Support',
        help: 'Help Center',
        contact: 'Contact Us',
        privacy: 'Privacy Policy',
        terms: 'Terms of Service'
      },
      contact: {
        title: 'Contact Info',
        address: 'Mumbai, Maharashtra, India',
        email: 'support@finbridge.ai',
        phone: '+91 98765 43210'
      },
      social: 'Follow Us',
      copyright: '© 2024 FinBridge. All rights reserved.',
      disclaimer: 'FinBridge is committed to responsible lending and financial inclusion.'
    },
    hi: {
      tagline: 'AI के माध्यम से वित्तीय समावेश को सशक्त बनाना',
      links: {
        product: 'उत्पाद',
        features: 'सुविधाएं',
        howItWorks: 'यह कैसे काम करता है',
        security: 'सुरक्षा',
        support: 'सहायता',
        help: 'सहायता केंद्र',
        contact: 'संपर्क करें',
        privacy: 'गोपनीयता नीति',
        terms: 'सेवा की शर्तें'
      },
      contact: {
        title: 'संपर्क जानकारी',
        address: 'मुंबई, महाराष्ट्र, भारत',
        email: 'support@finbridge.ai',
        phone: '+91 98765 43210'
      },
      social: 'हमारा अनुसरण करें',
      copyright: '© 2024 फिनब्रिज। सभी अधिकार सुरक्षित।',
      disclaimer: 'फिनब्रिज जिम्मेदार ऋण और वित्तीय समावेश के लिए प्रतिबद्ध है।'
    }
  };

  const text = content[language as keyof typeof content];

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-green-500 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">F</span>
              </div>
              <div>
                <h3 className="text-xl font-bold">FinBridge</h3>
              </div>
            </div>
            <p className="text-gray-300 mb-6 leading-relaxed">
              {text.tagline}
            </p>
            <div className="flex space-x-4">
              <Facebook className="w-6 h-6 text-gray-400 hover:text-white cursor-pointer transition-colors" />
              <Twitter className="w-6 h-6 text-gray-400 hover:text-white cursor-pointer transition-colors" />
              <Instagram className="w-6 h-6 text-gray-400 hover:text-white cursor-pointer transition-colors" />
              <Linkedin className="w-6 h-6 text-gray-400 hover:text-white cursor-pointer transition-colors" />
            </div>
          </div>
          
          {/* Product Links */}
          <div>
            <h4 className="font-semibold text-lg mb-6">{text.links.product}</h4>
            <ul className="space-y-3">
              <li><a href="#features" className="text-gray-300 hover:text-white transition-colors">{text.links.features}</a></li>
              <li><a href="#how-it-works" className="text-gray-300 hover:text-white transition-colors">{text.links.howItWorks}</a></li>
              <li><a href="#security" className="text-gray-300 hover:text-white transition-colors">{text.links.security}</a></li>
            </ul>
          </div>
          
          {/* Support Links */}
          <div>
            <h4 className="font-semibold text-lg mb-6">{text.links.support}</h4>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">{text.links.help}</a></li>
              <li><a href="#contact" className="text-gray-300 hover:text-white transition-colors">{text.links.contact}</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">{text.links.privacy}</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">{text.links.terms}</a></li>
            </ul>
          </div>
          
          {/* Contact Info */}
          <div>
            <h4 className="font-semibold text-lg mb-6">{text.contact.title}</h4>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-gray-400 mt-1 flex-shrink-0" />
                <span className="text-gray-300">{text.contact.address}</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-gray-400 flex-shrink-0" />
                <span className="text-gray-300">{text.contact.email}</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-gray-400 flex-shrink-0" />
                <span className="text-gray-300">{text.contact.phone}</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">{text.copyright}</p>
            <p className="text-gray-400 text-sm mt-4 md:mt-0">{text.disclaimer}</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
