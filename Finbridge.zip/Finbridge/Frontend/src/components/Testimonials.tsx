
import React from 'react';
import { Star, Quote } from 'lucide-react';

interface TestimonialsProps {
  language: string;
}

const Testimonials = ({ language }: TestimonialsProps) => {
  const content = {
    en: {
      title: 'Stories of Financial Inclusion',
      subtitle: 'Real people, real impact',
      testimonials: [
        {
          name: 'Priya Sharma',
          role: 'Street Vendor, Delhi',
          image: '👩‍💼',
          rating: 5,
          quote: 'FinBridge helped me get ₹10,000 to expand my vegetable stall. Now I earn 50% more and built my credit score to 720!'
        },
        {
          name: 'Rajesh Kumar',
          role: 'Auto Driver, Mumbai',
          image: '👨‍🔧',
          rating: 5,
          quote: 'No bank would give me a loan. FinBridge approved ₹25,000 in 5 minutes for my auto repairs. The voice feature made it so easy to use.'
        },
        {
          name: 'Meera Devi',
          role: 'Domestic Worker, Bangalore',
          image: '👩‍🏭',
          rating: 5,
          quote: 'I learned about savings and investments through the app games. Now I save ₹2,000 every month and my family has emergency funds.'
        }
      ]
    },
    hi: {
      title: 'वित्तीय समावेश की कहानियां',
      subtitle: 'वास्तविक लोग, वास्तविक प्रभाव',
      testimonials: [
        {
          name: 'प्रिया शर्मा',
          role: 'स्ट्रीट वेंडर, दिल्ली',
          image: '👩‍💼',
          rating: 5,
          quote: 'फिनब्रिज ने मुझे अपने सब्जी स्टॉल का विस्तार करने के लिए ₹10,000 पाने में मदद की। अब मैं 50% अधिक कमाती हूं और अपना क्रेडिट स्कोर 720 तक बनाया है!'
        },
        {
          name: 'राजेश कुमार',
          role: 'ऑटो ड्राइवर, मुंबई',
          image: '👨‍🔧',
          rating: 5,
          quote: 'कोई भी बैंक मुझे ऋण नहीं देता था। फिनब्रिज ने मेरे ऑटो की मरम्मत के लिए 5 मिनट में ₹25,000 मंजूर किया। आवाज की सुविधा ने इसे उपयोग करना बहुत आसान बना दिया।'
        },
        {
          name: 'मीरा देवी',
          role: 'घरेलू कामगार, बैंगलोर',
          image: '👩‍🏭',
          rating: 5,
          quote: 'मैंने ऐप गेम्स के माध्यम से बचत और निवेश के बारे में सीखा। अब मैं हर महीने ₹2,000 बचाती हूं और मेरे परिवार के पास आपातकालीन फंड है।'
        }
      ]
    }
  };

  const text = content[language as keyof typeof content];

  return (
    <section id="testimonials" className="py-20 bg-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            {text.title}
          </h2>
          <p className="text-xl text-gray-600">
            {text.subtitle}
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {text.testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white rounded-2xl p-8 shadow-sm hover:shadow-lg transition-shadow duration-300">
              <div className="flex items-center mb-6">
                <div className="text-4xl mr-4">{testimonial.image}</div>
                <div>
                  <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                  <p className="text-sm text-gray-600">{testimonial.role}</p>
                </div>
              </div>
              
              <div className="flex mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                ))}
              </div>
              
              <div className="relative">
                <Quote className="w-8 h-8 text-blue-200 absolute -top-2 -left-2" />
                <p className="text-gray-700 leading-relaxed pl-6">
                  {testimonial.quote}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
