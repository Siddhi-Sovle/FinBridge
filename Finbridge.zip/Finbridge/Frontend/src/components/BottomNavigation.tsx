
import React from 'react';
import { Home, CreditCard, BookOpen, User, Shield } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';

const BottomNavigation = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const navItems = [
    { icon: Home, label: 'होम', path: '/dashboard', labelEn: 'Home' },
    { icon: CreditCard, label: 'लोन', path: '/loan', labelEn: 'Loan' },
    { icon: BookOpen, label: 'सीखें', path: '/literacy', labelEn: 'Learn' },
    { icon: User, label: 'प्रोफाइल', path: '/profile', labelEn: 'Profile' },
    { icon: Shield, label: 'सुरक्षा', path: '/security', labelEn: 'Security' }
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50">
      <div className="flex justify-around items-center py-2">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          const Icon = item.icon;
          
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={`flex flex-col items-center py-2 px-3 rounded-lg transition-colors min-h-[60px] ${
                isActive 
                  ? 'text-blue-600 bg-blue-50' 
                  : 'text-gray-600 hover:text-blue-600'
              }`}
            >
              <Icon className="w-6 h-6 mb-1" />
              <span className="text-xs font-medium">{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default BottomNavigation;
