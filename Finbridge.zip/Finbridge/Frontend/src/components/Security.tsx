
import React from 'react';
import { Shield, Lock, Eye, Users } from 'lucide-react';

interface SecurityProps {
  language: string;
}

const Security = ({ language }: SecurityProps) => {
  const content = {
    en: {
      title: 'Security & Fairness First',
      subtitle: 'Your trust is our foundation',
      features: [
        {
          icon: Shield,
          title: 'Bank-Grade Encryption',
          description: 'All your data is protected with 256-bit SSL encryption, the same standard used by major banks.'
        },
        {
          icon: Eye,
          title: 'Explainable AI',
          description: 'Our AI decisions are transparent. You can always understand why you received a particular credit score or loan decision.'
        },
        {
          icon: Users,
          title: 'Fair Lending Practices',
          description: 'Our algorithms are designed to be bias-free and provide equal opportunities regardless of gender, caste, or religion.'
        },
        {
          icon: Lock,
          title: 'Data Privacy',
          description: 'Your personal information is never sold to third parties. You control what data you share and can delete it anytime.'
        }
      ],
      certifications: [
        'ISO 27001 Certified',
        'RBI Guidelines Compliant',
        'GDPR Compliant',
        'SOC 2 Type II'
      ]
    },
    hi: {
      title: 'सुरक्षा और निष्पक्षता सबसे पहले',
      subtitle: 'आपका भरोसा हमारी नींव है',
      features: [
        {
          icon: Shield,
          title: 'बैंक-ग्रेड एन्क्रिप्शन',
          description: 'आपका सभी डेटा 256-बिट SSL एन्क्रिप्शन से सुरक्षित है, वही मानक जो प्रमुख बैंकों द्वारा उपयोग किया जाता है।'
        },
        {
          icon: Eye,
          title: 'स्पष्ट एआई',
          description: 'हमारे एआई निर्णय पारदर्शी हैं। आप हमेशा समझ सकते हैं कि आपको कोई विशेष क्रेडिट स्कोर या ऋण निर्णय क्यों मिला।'
        },
        {
          icon: Users,
          title: 'निष्पक्ष ऋण प्रथाएं',
          description: 'हमारे एल्गोरिदम पूर्वाग्रह-मुक्त होने के लिए डिज़ाइन किए गए हैं और लिंग, जाति या धर्म की परवाह किए बिना समान अवसर प्रदान करते हैं।'
        },
        {
          icon: Lock,
          title: 'डेटा गोपनीयता',
          description: 'आपकी व्यक्तिगत जानकारी कभी भी तीसरे पक्ष को नहीं बेची जाती। आप नियंत्रित करते हैं कि कौन सा डेटा साझा करना है और इसे कभी भी हटा सकते हैं।'
        }
      ],
      certifications: [
        'ISO 27001 प्रमाणित',
        'RBI दिशानिर्देश अनुपालित',
        'GDPR अनुपालित',
        'SOC 2 Type II'
      ]
    }
  };

  const text = content[language as keyof typeof content];

  return (
    <section id="security" className="py-20 bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            {text.title}
          </h2>
          <p className="text-xl text-gray-300">
            {text.subtitle}
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {text.features.map((feature, index) => (
            <div key={index} className="bg-gray-800 rounded-2xl p-8">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-green-500 rounded-xl flex items-center justify-center mb-6">
                <feature.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-4">
                {feature.title}
              </h3>
              <p className="text-gray-300 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
        
        <div className="bg-gray-800 rounded-2xl p-8">
          <h3 className="text-2xl font-bold text-center mb-8">
            {language === 'en' ? 'Security Certifications' : 'सुरक्षा प्रमाणपत्र'}
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {text.certifications.map((cert, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Shield className="w-8 h-8 text-white" />
                </div>
                <p className="text-sm text-gray-300">{cert}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Security;
