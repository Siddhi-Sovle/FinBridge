
import React, { useState } from 'react';
import { Mic, MicOff } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface VoiceButtonProps {
  onVoiceCommand?: (command: string) => void;
  className?: string;
}

const VoiceButton = ({ onVoiceCommand, className = "" }: VoiceButtonProps) => {
  const [isListening, setIsListening] = useState(false);

  const toggleVoice = () => {
    setIsListening(!isListening);
    // Simulate voice recognition
    if (!isListening) {
      setTimeout(() => {
        setIsListening(false);
        onVoiceCommand?.("Voice command received");
      }, 2000);
    }
  };

  return (
    <Button
      onClick={toggleVoice}
      variant="outline"
      size="sm"
      className={`flex items-center space-x-2 ${isListening ? 'voice-active bg-green-50 border-green-500' : ''} ${className}`}
    >
      {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
      <span className="text-sm">{isListening ? 'सुन रहा है...' : 'आवाज़'}</span>
    </Button>
  );
};

export default VoiceButton;
