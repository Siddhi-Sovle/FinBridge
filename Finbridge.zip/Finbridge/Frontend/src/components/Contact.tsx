
import React, { useState } from 'react';
import { Phone, MessageCircle, MapPin, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from '@/hooks/use-toast';

interface ContactProps {
  language: string;
}

const Contact = ({ language }: ContactProps) => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    location: ''
  });

  const content = {
    en: {
      title: 'Get in Touch',
      subtitle: 'Ready to start your financial journey?',
      form: {
        name: 'Full Name',
        phone: 'Phone Number',
        location: 'Location (City, State)',
        submit: 'Get Started'
      },
      contact: {
        whatsapp: 'WhatsApp Support',
        sms: 'SMS Support',
        helpline: 'Helpline'
      },
      message: 'Thank you! We will contact you soon.',
      whatsappText: 'Hi, I want to learn more about FinBridge loans'
    },
    hi: {
      title: 'संपर्क में रहें',
      subtitle: 'अपनी वित्तीय यात्रा शुरू करने के लिए तैयार हैं?',
      form: {
        name: 'पूरा नाम',
        phone: 'फ़ोन नंबर',
        location: 'स्थान (शहर, राज्य)',
        submit: 'शुरुआत करें'
      },
      contact: {
        whatsapp: 'व्हाट्सऐप सहायता',
        sms: 'SMS सहायता',
        helpline: 'हेल्पलाइन'
      },
      message: 'धन्यवाद! हम जल्द ही आपसे संपर्क करेंगे।',
      whatsappText: 'नमस्ते, मैं फिनब्रिज ऋण के बारे में और जानना चाहता हूं'
    }
  };

  const text = content[language as keyof typeof content];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: text.message,
      description: language === 'en' ? "We'll reach out within 24 hours." : "हम 24 घंटे के भीतर संपर्क करेंगे।",
    });
    setFormData({ name: '', phone: '', location: '' });
  };

  const openWhatsApp = () => {
    window.open(`https://wa.me/919876543210?text=${encodeURIComponent(text.whatsappText)}`, '_blank');
  };

  return (
    <section id="contact" className="py-20 bg-gradient-to-r from-blue-600 to-green-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            {text.title}
          </h2>
          <p className="text-xl text-blue-100">
            {text.subtitle}
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Contact Form */}
          <div className="bg-white rounded-2xl p-8 shadow-xl">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {text.form.name}
                </label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  required
                  className="text-lg py-3"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {text.form.phone}
                </label>
                <Input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  required
                  className="text-lg py-3"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {text.form.location}
                </label>
                <Input
                  value={formData.location}
                  onChange={(e) => setFormData({...formData, location: e.target.value})}
                  required
                  className="text-lg py-3"
                />
              </div>
              
              <Button type="submit" size="lg" className="w-full bg-blue-600 hover:bg-blue-700 text-lg py-3">
                <Send className="w-5 h-5 mr-2" />
                {text.form.submit}
              </Button>
            </form>
          </div>
          
          {/* Contact Options */}
          <div className="space-y-6">
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6">
              <h3 className="text-2xl font-bold text-white mb-6">
                {language === 'en' ? 'Quick Contact' : 'त्वरित संपर्क'}
              </h3>
              
              <div className="space-y-4">
                <Button
                  onClick={openWhatsApp}
                  variant="outline"
                  size="lg"
                  className="w-full bg-green-500 hover:bg-green-600 text-white border-green-500 text-lg py-3"
                >
                  <MessageCircle className="w-5 h-5 mr-3" />
                  {text.contact.whatsapp}
                </Button>
                
                <Button
                  variant="outline"
                  size="lg"
                  className="w-full bg-white/20 hover:bg-white/30 text-white border-white/30 text-lg py-3"
                  onClick={() => window.open('sms:+919876543210', '_blank')}
                >
                  <Phone className="w-5 h-5 mr-3" />
                  {text.contact.sms}
                </Button>
                
                <div className="bg-white/10 rounded-lg p-4">
                  <div className="flex items-center text-white">
                    <Phone className="w-5 h-5 mr-3" />
                    <div>
                      <p className="font-semibold">{text.contact.helpline}</p>
                      <p className="text-blue-100">1800-123-4567</p>
                      <p className="text-sm text-blue-200">
                        {language === 'en' ? '24/7 Support' : '24/7 सहायता'}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
