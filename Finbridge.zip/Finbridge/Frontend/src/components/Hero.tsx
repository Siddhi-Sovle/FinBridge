
import React from 'react';
import { Download, Play, Smartphone, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface HeroProps {
  language: string;
}

const Hero = ({ language }: HeroProps) => {
  const content = {
    en: {
      title: 'AI-Powered Financial Assistance',
      subtitle: 'for the Underserved',
      description: 'Access microloans, build credit, and learn financial literacy through our simple, voice-enabled mobile app. No traditional bank account required.',
      cta: 'Download App',
      watchDemo: 'Watch Demo',
      features: [
        'No paperwork required',
        'Voice assistance in local languages',
        'Instant loan approval',
        'Build your credit score'
      ]
    },
    hi: {
      title: 'एआई-संचालित वित्तीय सहायता',
      subtitle: 'वंचितों के लिए',
      description: 'हमारे सरल, आवाज-सक्षम मोबाइल ऐप के माध्यम से माइक्रोलोन एक्सेस करें, क्रेडिट बनाएं और वित्तीय साक्षरता सीखें। पारंपरिक बैंक खाते की आवश्यकता नहीं।',
      cta: 'ऐप डाउनलोड करें',
      watchDemo: 'डेमो देखें',
      features: [
        'कोई कागजी कार्रवाई की आवश्यकता नहीं',
        'स्थानीय भाषाओं में आवाज सहायता',
        'तत्काल ऋण अनुमोदन',
        'अपना क्रेडिट स्कोर बनाएं'
      ]
    }
  };

  const text = content[language as keyof typeof content];

  return (
    <section className="bg-gradient-to-br from-blue-50 via-white to-green-50 py-12 sm:py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-left">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
              {text.title}
              <span className="block text-blue-600">{text.subtitle}</span>
            </h1>
            
            <p className="mt-6 text-lg sm:text-xl text-gray-600 leading-relaxed max-w-2xl">
              {text.description}
            </p>
            
            <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 text-lg">
                <Download className="w-5 h-5 mr-2" />
                {text.cta}
              </Button>
              
              <Button variant="outline" size="lg" className="px-8 py-4 text-lg">
                <Play className="w-5 h-5 mr-2" />
                {text.watchDemo}
              </Button>
            </div>
            
            <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {text.features.map((feature, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-white text-xs">✓</span>
                  </div>
                  <span className="text-gray-700">{feature}</span>
                </div>
              ))}
            </div>
          </div>
          
          {/* Right Visual */}
          <div className="relative">
            <div className="relative bg-gradient-to-r from-blue-500 to-green-500 rounded-3xl p-8 transform rotate-3 hover:rotate-0 transition-transform duration-300">
              <div className="bg-white rounded-2xl p-6 space-y-6">
                <div className="flex items-center space-x-3">
                  <Smartphone className="w-8 h-8 text-blue-600" />
                  <span className="text-lg font-semibold">FinBridge App</span>
                </div>
                
                <div className="space-y-4">
                  <div className="bg-green-50 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Credit Score</span>
                      <Shield className="w-4 h-4 text-green-600" />
                    </div>
                    <div className="text-2xl font-bold text-green-600 mt-1">750</div>
                    <div className="text-xs text-gray-500">+50 this month</div>
                  </div>
                  
                  <div className="bg-blue-50 rounded-lg p-4">
                    <div className="text-sm text-gray-600">Available Loan</div>
                    <div className="text-2xl font-bold text-blue-600 mt-1">₹25,000</div>
                    <div className="text-xs text-gray-500">Interest: 12% p.a.</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
