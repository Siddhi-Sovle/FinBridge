
import React from 'react';
import { Brain, CreditCard, BookOpen, Mic, Shield, Zap } from 'lucide-react';

interface FeaturesProps {
  language: string;
}

const Features = ({ language }: FeaturesProps) => {
  const content = {
    en: {
      title: 'Empowering Financial Inclusion',
      subtitle: 'Advanced AI technology designed for everyone',
      features: [
        {
          icon: Brain,
          title: 'Alternative Credit Scoring',
          description: 'Our AI analyzes alternative data to assess creditworthiness without traditional bank history.'
        },
        {
          icon: CreditCard,
          title: 'Instant Microloans',
          description: 'Get approved for loans from ₹1,000 to ₹50,000 in minutes, not days.'
        },
        {
          icon: BookOpen,
          title: 'Gamified Financial Literacy',
          description: 'Learn money management through interactive games and earn rewards.'
        },
        {
          icon: Mic,
          title: 'Voice Interface',
          description: 'Use the app in your preferred language with voice commands and audio guidance.'
        },
        {
          icon: Shield,
          title: 'Data Privacy',
          description: 'Your data is encrypted and never shared without your explicit consent.'
        },
        {
          icon: Zap,
          title: 'Offline-First',
          description: 'Core features work even with poor internet connectivity.'
        }
      ]
    },
    hi: {
      title: 'वित्तीय समावेश को सशक्त बनाना',
      subtitle: 'सभी के लिए डिज़ाइन की गई उन्नत एआई तकनीक',
      features: [
        {
          icon: Brain,
          title: 'वैकल्पिक क्रेडिट स्कोरिंग',
          description: 'हमारा एआई पारंपरिक बैंक इतिहास के बिना साख का आकलन करने के लिए वैकल्पिक डेटा का विश्लेषण करता है।'
        },
        {
          icon: CreditCard,
          title: 'तत्काल माइक्रोलोन',
          description: 'दिनों में नहीं, मिनटों में ₹1,000 से ₹50,000 तक के ऋण के लिए अनुमोदन प्राप्त करें।'
        },
        {
          icon: BookOpen,
          title: 'गेमिफाइड वित्तीय साक्षरता',
          description: 'इंटरैक्टिव गेम्स के माध्यम से पैसे का प्रबंधन सीखें और पुरस्कार अर्जित करें।'
        },
        {
          icon: Mic,
          title: 'आवाज इंटरफ़ेस',
          description: 'आवाज कमांड और ऑडियो गाइडेंस के साथ अपनी पसंदीदा भाषा में ऐप का उपयोग करें।'
        },
        {
          icon: Shield,
          title: 'डेटा गोपनीयता',
          description: 'आपका डेटा एन्क्रिप्टेड है और आपकी स्पष्ट सहमति के बिना कभी साझा नहीं किया जाता।'
        },
        {
          icon: Zap,
          title: 'ऑफ़लाइन-फर्स्ट',
          description: 'खराब इंटरनेट कनेक्टिविटी के साथ भी मुख्य सुविधाएं काम करती हैं।'
        }
      ]
    }
  };

  const text = content[language as keyof typeof content];

  return (
    <section id="features" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            {text.title}
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {text.subtitle}
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {text.features.map((feature, index) => (
            <div key={index} className="bg-gray-50 rounded-2xl p-8 hover:shadow-lg transition-shadow duration-300">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-green-500 rounded-xl flex items-center justify-center mb-6">
                <feature.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">
                {feature.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
