
import React from 'react';
import { Menu, Globe, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface HeaderProps {
  language: string;
  setLanguage: (lang: string) => void;
}

const Header = ({ language, setLanguage }: HeaderProps) => {
  const content = {
    en: {
      title: 'FinBridge',
      tagline: 'Financial Inclusion for All',
      contact: 'Contact Us'
    },
    hi: {
      title: 'फिनब्रिज',
      tagline: 'सभी के लिए वित्तीय समावेश',
      contact: 'संपर्क करें'
    }
  };

  const text = content[language as keyof typeof content];

  return (
    <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-green-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">F</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">{text.title}</h1>
              <p className="text-sm text-gray-600">{text.tagline}</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLanguage(language === 'en' ? 'hi' : 'en')}
              className="flex items-center space-x-2"
            >
              <Globe className="w-4 h-4" />
              <span>{language === 'en' ? 'हिंदी' : 'English'}</span>
            </Button>
            
            <Button variant="outline" size="sm" className="hidden sm:flex items-center space-x-2">
              <Phone className="w-4 h-4" />
              <span>{text.contact}</span>
            </Button>
            
            <Button variant="ghost" size="sm" className="sm:hidden">
              <Menu className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
