
import React from 'react';
import { UserPlus, Database, Calculator, CreditCard, RefreshCw } from 'lucide-react';

interface HowItWorksProps {
  language: string;
}

const HowItWorks = ({ language }: HowItWorksProps) => {
  const content = {
    en: {
      title: 'How FinBridge Works',
      subtitle: 'Simple steps to financial inclusion',
      steps: [
        {
          icon: UserPlus,
          title: 'Sign Up',
          description: 'Create your account with just your phone number. No paperwork required.'
        },
        {
          icon: Database,
          title: 'Data Collection',
          description: 'Our AI safely analyzes your mobile usage patterns and basic information.'
        },
        {
          icon: Calculator,
          title: 'Credit Scoring',
          description: 'Get your personalized credit score based on alternative data points.'
        },
        {
          icon: CreditCard,
          title: 'Loan Approval',
          description: 'Receive instant loan approval and funds directly to your mobile wallet.'
        },
        {
          icon: RefreshCw,
          title: 'Build Credit',
          description: 'Make timely repayments to improve your credit score for larger loans.'
        }
      ]
    },
    hi: {
      title: 'फिनब्रिज कैसे काम करता है',
      subtitle: 'वित्तीय समावेश के लिए सरल कदम',
      steps: [
        {
          icon: UserPlus,
          title: 'साइन अप करें',
          description: 'केवल अपने फ़ोन नंबर के साथ अपना खाता बनाएं। कोई कागजी कार्रवाई की आवश्यकता नहीं।'
        },
        {
          icon: Database,
          title: 'डेटा संग्रह',
          description: 'हमारा एआई आपके मोबाइल उपयोग पैटर्न और बुनियादी जानकारी का सुरक्षित विश्लेषण करता है।'
        },
        {
          icon: Calculator,
          title: 'क्रेडिट स्कोरिंग',
          description: 'वैकल्पिक डेटा पॉइंट्स के आधार पर अपना व्यक्तिगत क्रेडिट स्कोर प्राप्त करें।'
        },
        {
          icon: CreditCard,
          title: 'ऋण अनुमोदन',
          description: 'तत्काल ऋण अनुमोदन प्राप्त करें और सीधे अपने मोबाइल वॉलेट में धन प्राप्त करें।'
        },
        {
          icon: RefreshCw,
          title: 'क्रेडिट बनाएं',
          description: 'बड़े ऋणों के लिए अपने क्रेडिट स्कोर में सुधार के लिए समय पर चुकौती करें।'
        }
      ]
    }
  };

  const text = content[language as keyof typeof content];

  return (
    <section id="how-it-works" className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            {text.title}
          </h2>
          <p className="text-xl text-gray-600">
            {text.subtitle}
          </p>
        </div>
        
        <div className="relative">
          {/* Connection Line */}
          <div className="hidden lg:block absolute top-16 left-1/2 transform -translate-x-1/2 w-full max-w-4xl">
            <div className="flex justify-between">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="w-px h-16 bg-gradient-to-b from-blue-300 to-green-300"></div>
              ))}
            </div>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-4">
            {text.steps.map((step, index) => (
              <div key={index} className="text-center group">
                <div className="relative mb-6">
                  <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center mx-auto group-hover:scale-110 transition-transform duration-300">
                    <step.icon className="w-8 h-8 text-white" />
                  </div>
                  <div className="absolute -top-2 -right-2 w-8 h-8 bg-white border-4 border-blue-500 rounded-full flex items-center justify-center text-sm font-bold text-blue-600">
                    {index + 1}
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">
                  {step.title}
                </h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
