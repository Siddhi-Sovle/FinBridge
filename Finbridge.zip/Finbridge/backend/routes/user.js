import express from 'express';
const router = express.Router();

// Mock user data store (replace with DB)
let userData = {
  id: 'user123',
  name: 'राहुल',
  email: 'rahul@example.com',
  creditScore: 720,
  personalData: {
    phoneUsage: 'regular',
    rentPayment: 'on time',
    // ... other fields
  },
  accountActive: true,
};

// Middleware placeholder for authentication
const authenticate = (req, res, next) => {
  // TODO: Verify user token/session here
  req.user = userData; // For now, attach mock user
  next();
};

router.use(authenticate);

// Download user data
router.get('/download-data', (req, res) => {
  const dataToSend = {
    name: req.user.name,
    email: req.user.email,
    creditScore: req.user.creditScore,
    personalData: req.user.personalData,
  };
  res.setHeader('Content-Disposition', 'attachment; filename=user-data.json');
  res.setHeader('Content-Type', 'application/json');
  res.send(JSON.stringify(dataToSend, null, 2));
});

// Delete user data
router.delete('/delete-data', (req, res) => {
  // In real DB: delete or anonymize user personal data
  userData.personalData = {};
  res.status(200).json({ message: 'आपका डेटा सफलतापूर्वक हटा दिया गया है।' });
});

// Close account
router.post('/close-account', (req, res) => {
  // Mark account as inactive in DB
  userData.accountActive = false;
  res.status(200).json({ message: 'आपका खाता बंद कर दिया गया है।' });
});

// Contact security team (support ticket)
router.post('/contact-security', (req, res) => {
  const { message } = req.body;
  if (!message) {
    return res.status(400).json({ error: 'संदेश आवश्यक है।' });
  }

  // TODO: Save ticket in DB or send email to security team
  console.log(`Security message from user: ${message}`);

  res.status(200).json({ message: 'आपका संदेश सुरक्षा टीम को भेज दिया गया है।' });
});

export default router;
